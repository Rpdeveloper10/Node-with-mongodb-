var express = require('express');
var mongoose = require('mongoose');

//item Schema require..........
var item = require('../model/item');

mongoose.connect('mongodb://localhost:27017/shopping',{ useNewUrlParser: true });

var app = express();

//Get Itomes Api..............
app.get('/items', function(req, res){
	item.find(function(err, items){
     if(err){
     	res.json(err);
     }else{
     	res.json({
            items:items,
     		status:true,
    	    "message":"items Fetch Successfully!!"});
     }
	});
});

//Post Itome Api..............
app.post('/item', function(req, res){
   var newitem = new item({
           itemName:req.body.itemName,
           itemDisc:req.body.itemDisc,
           itemQnty:req.body.itemQnty
   });
   newitem.save(function(err, item){
      if(err){
      	res.json(err);
      }else{
      	res.json({
      		status:true,
    	    "message":"1 Record Added Successfully!!"});
      }
   });
});

//Put/ Update Itome Api..............
app.put('/item/:id', function(req, res){
   item.findOneAndUpdate({_id:req.params.id},{
     $set:{
     	itemName:req.body.itemName,
     	itemDisc:req.body.itemDisc,
     	itemQnty:req.body.itemQnty
     }
   },function(err, result){
      if(err){
      	res.json(err);
      }else{
      	res.json({
      	    result:result,
     		status:true,
    	    "message":"Record Update Successfully!!"});	
        }
   });
});

//Delete Itome Api..............
app.delete('/item/:id', function(req, res){
   item.remove({_id:req.params.id},function(err, result){
     if(err){
     	res.json(err);
     }else{
     	res.json({
     		result:result,
     		status:true,
    	    "message":"Record Deleted Successfully!!"});
     }
   });
});


module.exports = app;