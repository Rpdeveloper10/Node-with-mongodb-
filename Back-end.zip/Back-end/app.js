//Modules Require...................
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongodb');
var cors = require('cors');

//Express Store in app.............
var app = express();

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// parse requests of content-type - application/json
app.use(bodyParser.json());

//cors is use............
app.use(cors());

//Require routes file for all api.................
var indexRouter = require('./routes/index');

//Use '/' routes............ 
app.use('/',indexRouter);

//Create a server & Port Listenting...........
var PORT = 3000;
app.listen(PORT, function(err, res){
   console.log('Listen to '+PORT);    
});