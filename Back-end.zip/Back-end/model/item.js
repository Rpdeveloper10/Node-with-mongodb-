var mongoose = require('mongoose');

// Collection name items ...............
var itemSchema = mongoose.Schema({
      itemName:{
      	type:String,
        require:true
      },
      itemDisc:{
      	type:String,
      	require:true
      },
      itemQnty:{
      	type:String,
      	require:true
      }
});

var item = module.exports=mongoose.model('item',itemSchema);